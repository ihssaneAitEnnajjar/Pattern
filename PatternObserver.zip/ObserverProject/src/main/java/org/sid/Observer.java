package org.sid;

public interface Observer {
    public void update(int state);

}
