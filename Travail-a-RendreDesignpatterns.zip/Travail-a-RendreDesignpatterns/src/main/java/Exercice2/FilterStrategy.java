package Exercice2;

public interface FilterStrategy {
    int[] filter(int[] data);
}
