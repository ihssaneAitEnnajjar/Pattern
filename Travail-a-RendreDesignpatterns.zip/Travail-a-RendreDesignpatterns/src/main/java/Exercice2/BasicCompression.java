package Exercice2;

public class BasicCompression extends CompressAlgorithm {
    @Override
    protected int[] compressData(int[] data) {
        return data;
    }
}

