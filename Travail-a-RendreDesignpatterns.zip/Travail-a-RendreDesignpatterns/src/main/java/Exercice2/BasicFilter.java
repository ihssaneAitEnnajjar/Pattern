package Exercice2;

public class BasicFilter implements FilterStrategy {
    @Override
    public int[] filter(int[] data) {
        return data;
    }
}

