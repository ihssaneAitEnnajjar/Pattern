package Exercice1.Situation2TemplateMethodPattern;

public class PluginConcret extends Plugin {
    @Override
    protected void partie1() {
    }

    @Override
    protected void partie2() {
    }
}
