package Exercice1.Situation2TemplateMethodPattern;

public class Main {
    public static void main(String[] args) {
        Plugin plugin = new PluginConcret();
        plugin.squeletteAlgorithme();
    }
}

