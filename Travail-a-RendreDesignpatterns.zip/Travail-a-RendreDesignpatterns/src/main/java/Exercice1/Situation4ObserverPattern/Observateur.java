package Exercice1.Situation4ObserverPattern;

public interface Observateur {
    void mettreAJour(int score);
}
