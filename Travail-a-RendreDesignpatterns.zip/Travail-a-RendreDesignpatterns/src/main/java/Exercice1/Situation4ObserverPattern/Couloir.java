package Exercice1.Situation4ObserverPattern;

public class Couloir implements Observateur {
    @Override
    public void mettreAJour(int score) {
    }
}

