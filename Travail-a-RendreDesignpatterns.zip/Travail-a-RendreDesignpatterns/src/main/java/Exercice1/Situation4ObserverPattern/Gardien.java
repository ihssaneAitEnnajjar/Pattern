package Exercice1.Situation4ObserverPattern;

public class Gardien implements Observateur {
    @Override
    public void mettreAJour(int score) {
    }
}
