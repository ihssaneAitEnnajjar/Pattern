package Exercice1.Situation3DecoratorPattern;

public class ComponentConcrete implements ComponentInterface {
    @Override
    public void traitement() {
    }
}
