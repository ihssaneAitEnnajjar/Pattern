package Exercice1.Situation3DecoratorPattern;

public interface ComponentInterface {
    void traitement();
}
