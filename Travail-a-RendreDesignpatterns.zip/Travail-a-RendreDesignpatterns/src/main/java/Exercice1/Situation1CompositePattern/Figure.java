package Exercice1.Situation1CompositePattern;

public interface Figure {
    void dessiner();
}

