package Exercice1.Situation1CompositePattern;

public class Rectangle implements Figure {
    @Override
    public void dessiner() {
    }
}
